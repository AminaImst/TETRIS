const tetris = document.getElementById("tetris");
const contexte = tetris.getContext("2d");
const scoreElement = document.getElementById("score");

const ROW = 20;
const COL = COLUMN = 10;
const SQUARE = squareSize = 20;
const VACANT = "#FF54FF";//Couleur d'un carré vide

// DESSINER UN CARRÉ
function drawSquare(x,y,couleur){
    contexte.fillStyle = couleur;
    contexte.fillRect(x*SQUARE,y*SQUARE,SQUARE,SQUARE);

    contexte.strokeStyle = "green";
    contexte.strokeRect(x*SQUARE,y*SQUARE,SQUARE,SQUARE);
}

// CRÉER LE TABLEAU
let board = [];
for( r = 0; r <ROW; r++){ //Boucle sur la constante ROW, initalisé à un 20
    board[r] = []; //Chaque case présente dans chaque colonne devient un tableau
    for(c = 0; c < COL; c++){
        board[r][c] = VACANT; //Les cases r et c de la matrice sont vacant
    }
}

// DESSINER LE TABLEAU
function drawBoard(){
    for( r = 0; r <ROW; r++){
        for(c = 0; c < COL; c++){
            drawSquare(c,r,board[r][c]);
        }
    }
}
drawBoard();

// LES PIECES ET LEURS COULEURS
const PIECES = [
    [Z,"#2D8D91"],
    [S,"white"],
    [T,"yellow"],
    [O,"#090007"],
    [L,"purple"],
    [I,"cyan"],
    [J,"orange"]
];


// GÉNÉRER UNE PIECE ALÉATOIREMENT
function randomPiece(){
    //Retourne une valeur entre 0 et 6
    let r = randomN = Math.floor(Math.random() * PIECES.length)
    return new Piece( PIECES[r][0],PIECES[r][1]);
}

//INITIALISER UNE PIECE
let piece = randomPiece();


// CRÉATION D'UN CONSTRUCTEUR POUR LES PIECES
function Piece(tetromino,couleur){
    this.tetromino = tetromino;
    this.couleur = couleur;
    
    this.tetrominoN = 0; // Commence par le premier modèle
    this.activeTetromino = this.tetromino[this.tetrominoN];//Correspond à la pièce avec laquelle on joue
    
    // Contrôler les pièces. Axe des abscisses et ordonnées.
    this.x = 3;
    this.y = -2;
}

// FONCTION FILL : pour aérer le code. Utile draw/undraw une pièce
Piece.prototype.fill = function(couleur){
    for( r = 0; r < this.activeTetromino.length; r++){
        for(c = 0; c < this.activeTetromino.length; c++){
            // On ne dessine que les carrés occupés. 
            if( this.activeTetromino[r][c]){
                //Pour contrôler la pièce on doit ajouter les axes y/x
                drawSquare(this.x + c,this.y + r, couleur);
            }
        }
    }
}

// DESSINER UNE PIECE DANS LE TABLEAU.
Piece.prototype.draw = function(){
    this.fill(this.couleur);
}

// FONCTION POUR "BLOQUER" UNE PIECE DANS LE TABLEAU. Change de couleur à la pièce. 
Piece.prototype.unDraw = function(){
    this.fill(VACANT);
}

// FONCTION POUR FAIRE DESCENDRE UNE PIECE. On doit incrémenter l'axe y
Piece.prototype.moveDown = function(){
    if(!this.collision(0,1,this.activeTetromino)){ //S'il n'y a pas de collison, alors je fais le mouvement
        this.unDraw();
        this.y++;
        this.draw();
    }else{
        // Sinon, bloque la pièce, et on en génére une autre. 
        this.lock();
        piece = randomPiece();
    }
    
}

// FONCTION POUR FAIRE BOUGER LA PIECE A DROITE. Incrémente l'axe x
Piece.prototype.moveRight = function(){
    if(!this.collision(1,0,this.activeTetromino)){
        this.unDraw();
        this.x++;
        this.draw();
    }
}

// FONCTION POUR FAIRE BOUGER LA PIECE A GAUCHE. Décrémente l'axe x
Piece.prototype.moveLeft = function(){
    if(!this.collision(-1,0,this.activeTetromino)){
        this.unDraw();
        this.x--;
        this.draw();
    }
}

// FONCTION POUR FAIRE PIVOTER LA PIECE
Piece.prototype.rotate = function(){
    let nextPattern = this.tetromino[(this.tetrominoN + 1)%this.tetromino.length];
    let kick = 0;
    //Besoin de savoir ou survient la collision
    if(this.collision(0,0,nextPattern)){
        if(this.x > COL/2){
            // C'est le côté droit
            kick = -1; // Alors on le pousse du côté gauche
        }else{
            // C'est le côté gauche
            kick = 1; // Alors on kick du côté droit
        }
    }
    //S'il n'y a pas de collison, alors on kick la pièce
    if(!this.collision(kick,0,nextPattern)){
        this.unDraw();
        this.x += kick;
        this.tetrominoN = (this.tetrominoN + 1)%this.tetromino.length; // (0+1)%4 => 1
        this.activeTetromino = this.tetromino[this.tetrominoN];
        this.draw();
    }
}

let score = 0;
//FONCTION POUR BLOQUER LES PIECES
Piece.prototype.lock = function(){
    for( r = 0; r < this.activeTetromino.length; r++){
        for(c = 0; c < this.activeTetromino.length; c++){
            // Si le carré est vide, on ne souhaite pas le bloquer, donc on continu
            if( !this.activeTetromino[r][c]){
                continue;
            }
            // Vérification pour savoir si la pièce est bloqué en haut du tableau
            if(this.y + r < 0){
                // alert("GAME OVER"); //C'est GAME OVER

                document.getElementById('finish').style.display='block';
                stockScore();
                afficheScore();

                // On stop requestAnimationFrame
                gameOver = true;
                break;
            }
            // On bloque la pièce : change de couleur
            board[this.y+r][this.x+c] = this.couleur;
        }
    }
    // Supprimer une rangée une fois pleine
    for(r = 0; r < ROW; r++){
        let isRowFull = true;
        for( c = 0; c < COL; c++){
            isRowFull = isRowFull && (board[r][c] != VACANT);
        }
        if(isRowFull){
            // Si la rangée est pleine, on déplace toute les rangées au dessus d'elle
            for( y = r; y > 1; y--){
                for( c = 0; c < COL; c++){
                    board[y][c] = board[y-1][c];
                }
            }
            // La rangée tout en haut n'a pas de rangée au dessus d'elle -> board[0][..]
            for( c = 0; c < COL; c++){
                board[0][c] = VACANT;
            }
            // INCRÉMENTER LE SCORE PAR 10
            score += 10;
        }
    }
    stockScore();

    // Mettre à jour le tableau
    drawBoard();
    
    // Mettre à jour le score
    scoreElement.innerHTML = score;
}


// FONCTION DE COLLISION
Piece.prototype.collision = function(x,y,piece){
    for( r = 0; r < piece.length; r++){
        for(c = 0; c < piece.length; c++){
            // Vérification : si le carré est vide/vacant, on l'ignore, et on continue
            if(!piece[r][c]){
                continue;
            }
            // Les coordonnées de la pièce, après le mouvement
            let newX = this.x + c + x;
            let newY = this.y + r + y;
            
            // Ajout des conditions (bordures du canvas)
            if(newX < 0 || newX >= COL || newY >= ROW){
                return true;
            }
            // Si newY est inférieur à o, ça ne fonctionne pas, car il n'y a pas 
            //d'index -1 (fait crash le jeu)
            if(newY < 0){
                continue;
            }
            // Vérification pour savoir si'l y a déjà une pièce bloquée dans le tableau
            if( board[newY][newX] != VACANT){ // Si la case, au nouvelle coordonnée est différent de VACANT
                return true;
            }
        }
    }
    return false;
}


// EVENEMENTS POUR CONTROLER LA PIECE
document.addEventListener("keydown",CONTROL);

function CONTROL(event){
    
        if(event.keyCode == 37){
            piece.moveLeft();
            dropStart = Date.now();
        }else if(event.keyCode == 38){
            piece.rotate();
            dropStart = Date.now();
        }else if(event.keyCode == 39){
            piece.moveRight();
            dropStart = Date.now();
        }else if(event.keyCode == 40){
            piece.moveDown();
        }

}
// FAIRE TOMBER UNE PIECE TOUTE LES SECONDES
let dropStart = Date.now();
let gameOver = false;
function drop(){
    let now = Date.now();
    let delta = now - dropStart;
    if(delta > 1000){
        piece.moveDown();
        dropStart = Date.now();
    }
    if(!gameOver)
    {
        requestAnimationFrame(drop);
    }

}

//drop();


//FONCTION POUR AFFICHER L'HEURE: création d'une fonction auto-invoquée
(function () {
    //Faire en sorte que les heures inférieurs à 10 s'affiche avec un 0 devant. 
    function checkTime(i) {
        return (i < 10) ? "0" + i : i;
    }

    function startTime() {
        var today = new Date(),
            h = checkTime(today.getHours()),
            m = checkTime(today.getMinutes()),
            s = checkTime(today.getSeconds());
        let time = document.getElementById('time').innerHTML = "Il est " + h + " : " + m + " : " + s;
        t = setTimeout(function () {
            startTime()
        }, 500);
    }
    time.style.fontFamily = 'Orbitron';

    startTime();
})();



//FONCTION POUR REDÉMARRER LE JEU
function restart(){
    //Appel des fonctions suivante pour dessiner le tableau et générer une 
    //nouvelle pièce 
    gameOver=false;
    board = [];
    for( r = 0; r <ROW; r++){ //Boucle sur la constante ROW, initalisé à un 20
        board[r] = []; //Chaque case présente dans chaque colonne devient un tableau
        for(c = 0; c < COL; c++){
            board[r][c] = VACANT; //Les cases r et c de la matrice sont vacant
        }
    }

    document.getElementById('finish').style.display='none';
    let score = 0;
    drawBoard();
    piece = randomPiece();
    drop();
    
}

function start(){
    document.getElementById('open').style.display='none';
    drop();
}

function finish(){
    document.getElementById('finish').style.display='block';

}

function stockScore(){
    var score = localStorage.getItem('score');
    localStorage.setItem('score', score);
    return score;
}

//AFFICHER LE SCORE UNE FOIS QUE LE JOUEUR A PERDU
function afficheScore(){
    var scoreFinal = document.getElementById('caca');
    scoreFinal.innerHTML = score;
    console.log(score);
}