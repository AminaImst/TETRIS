const tetris = document.getElementById("tetris");
const contexte = tetris.getContext('2d');
const scoreElement = document.getElementById('score');

const ROW = 40;
const COL = COLUMN = 10;
const SQUARE = squareSize = 30;
//Carrée vide
const VACANT = "white";


//DESSINER UN CARRÉ
function drawSquare(x, y, color){
    contexte.fillStyle = color;
    contexte.fillRect(x*SQUARE, y*SQUARE, SQUARE, SQUARE);

    contexte.strokeStyle = "green";
    contexte.strokeRect(x*SQUARE, y*SQUARE, SQUARE, SQUARE);
}

//drawSquare(0,0,"white");

//CRÉER LE TABLEAU
let board = [];
//Boucle sur la constante ROW qui est initialisé à 20. 
for(r = 0; r < ROW; r++){
    //La colonne r de board est un tableau lui aussi. 
    board[r] = [];
    //Boucle sur la constante COL qui est initialisé.
    for(c = 0; c < COL; c++){
        //La case r et c de la matrice sont vacant. 
        board[r][c] = VACANT;
    }
}


//DESSINER LE TABLEAU
function drawBoard(){
    for(r = 0; r < ROW; r++){
        board[r] = [];
        for(c=0; c < COL; c++){
            drawSquare(c, r, board[r][c])
        }
    }
    //Simple debug
    console.log(board);
}    
drawBoard();


//LES PIECES ET LEURS COULEURS
const PIECES = [
    [S,"#ff5733"],
    [T,"yellow"],
    [O,"blue"],
    [L,"purple"],
    [I,"cyan"],
    [J,"orange"],    
    [Z,"red"]
];
//GENERER UNE PIECE ALÉATOIREMENT
function randomPiece(){
    //Retourne une valeur entre 0 et 6
    let r  = randomN = Math.floor(Math.random() * PIECES.length)
    return new Piece(PIECES[r][0], PIECES[r][1]);
}

//INITIALISER UNE PIECE
let piece = randomPiece();

//CRÉATION D'UN OBJET PIECE
//Constructeur pour les pièces
function Piece(tetromino, couleur){

    this.tetromino = tetromino;
    this.couleur = couleur;
    //Commence par le premier modèle
    this.tetrominoN = 0;
    //C'est le tetromino avec lequel on joue : va correspondre à un tetromino N
    this.activeTetromino = this.tetromino[this.tetrominoN];

    //Contrôler les pièces
    //Initialise les pièces avce pour axe des abscisses et des ordonnées 0
    this.x = 3;
    this.y = -2;
  
}
// FONCTION FILL : pour aérer le code. Utile pour draw/undraw une pièce
Piece.prototype.fill = function(couleur){
    for(r = 0; r < this.activeTetromino.length; r++){
        //board[r] = [];
        for(c = 0; c < this.activeTetromino.length; c++){
            //Dessine uniquement les carrés occupés. 
            if( this.activeTetromino[r][c]){
                //Pour contrôler la pièce on doit ajouter les axes x et y
                drawSquare(this.x + c, this.y + r, couleur);
            }
        }
    }
}
//DESSINER UNE PIECE DANS LE TABLEAU. Ajoute à l'objet Piece la fonction draw. 
Piece.prototype.draw = function(){
    this.fill(this.couleur);
}

// FONCTION POUR BLOQUER LA PIECE PRECEDENTE OU LA DERNIERE. undraw a piece
Piece.prototype.unDraw = function(){
    this.fill(VACANT);
}


//FONCTION POUR FAIRE BOUGER LA PIECE A DROITE. Incrémente l'axe x
Piece.prototype.moveRight = function(){
    if(!this.collision(1, 0, this.activeTetromino)){
        this.unDraw();
        this.x++;
        this.draw();   
    }
}

//FONCTION POUR FAIRE BOUGER LA PIECE A GAUCHE. Décrémente l'axe x
Piece.prototype.moveLeft = function(){
    if(!this.collision(-1, 0, this.activeTetromino)){
        this.unDraw();
        this.x--;
        this.draw();  
    }
    
}
// FAIRE DESCENDRE LA PIECE. On doit incrémenter l'axe y
Piece.prototype.moveDown = function(){
    //S'il n'y a pas de collision, alors je fais le mouvement
    if(!this.collision(0, 1, this.activeTetromino)){
        this.unDraw();
        this.y++;
        this.draw(); 
    } else {
        // Sinon, on bloque la pièce, et on en génére une autre
        this.lock();
        piece = randomPiece();
    }
    
}

// // FAIRE PIVOTER LA PIECE.
Piece.prototype.rotate = function(){
    let nextPattern = this.tetromino[(this.tetrominoN + 1) % this.tetromino.length];
    let kick = 0;    
    //Besoin de savoir ou survient la collision
    if(!this.collision(0, 0, nextPattern)){
        if(this.x > COL/2){
            //C'est le côté droit
            kick = -1; //Alors on le pousse du côté gauche
        }else{
            //C'est le côté gauche
            kick = 1; //Alors on kick du côté droit
        }
    }
    //S'il n'y a pas de collusion après le kick, alors on kick la pièce
    if(!this.collision(kick, 0, nextPattern)){
        this.unDraw();
        this.x += kick;
        this.tetrominoN = (this.tetrominoN + 1)%this.tetromino.length;
        this.activeTetromino = this.tetromino[this.tetrominoN];
        this.draw();   
    }
    
}

let score = 0;
//FONCTION POUR BLOQUER LES PIECES
Piece.prototype.lock = function(){
    //Boucler sur tous les carrés de tetromino
    for(r=0; r < this.activeTetromino.length; r++){
        //board[r] = [];
        for(c=0; c < this.activeTetromino.length; c++){
            //Ignorer un carré vide, on ne souhaite pas bloquer le carré vide au tableau
            if( !this.activeTetromino[r][c]){
                continue;
            }//Maintenant on vérifie si la pièce est bloquer en haut du tableau = GAME OVER
            if(this.y + r < 0){
                alert("GAME OVER");
                //STOP requestanimationFrame
                gameOver = true;
                break;
            }
            //On bloque la pièce : change de couleur
            board[this.y +r ][this.x + c] = this.couleur;
        }
    }
    //SUPPRIMER UNE RANGÉE UNE FOIS PLEINE
    for(r = 0; c < ROW; r++){
        let isRowFull = true;
        for (c = 0; c < COL; c++){
            isRowFull = isRowFull && (board[r][c]) != VACANT;
        }
        if(isRowFull){
            //Si la rangée est pleine, on déplace toute les rangées au dessus d'elle
            for( y = r; y > 1; y--){
                for(c = 0; c < COL; c++){
                    board[y][c] = board[y-1][c]
                }
            }
            //La rangée tout en haut n'a pas de rangée au dessus d'elle
            //board[0][..]
            for(c = 0; c < COL; c++){
                board[0][c] = VACANT;
            }
            //INCRÉMENTER LE SCORE PAR 10
            score += 10;
        }
    }
    //METTRE A JOUR LE TABLEAU
    drawBoard();
    //METTRE A JOUR LE SCORE
    scoreElement.innerHTML = score;
}


// FONCTION DE COLLISIONS

Piece.prototype.collision = function(x, y, piece){
    for(r=0; r < piece.length; r++){
        for(c=0; c < piece.length; c++){
           // Vérification : si le carré est vide/vacant, on l'ignore, et on continue.
           if(!piece[r][c]){
                continue;
           }
           // Les coordonnées de la pièce, après mouvement
           let newX = this.x + c + x;
           let newY = this.y + r + y;

           //Ajout des conditions (bordures du canvas)
           if(newX < 0 || newX >= COL || newY >= ROW){
               return true;
           }
           // Si newY est inférieur à 0, ça ne fonctionne pas, car il n'y a pas
           //d'index -1 (fait crash le jeu)
           if(newY < 0){
               continue;
           }
           //Vérification pour savoir s'il y a déjà une pièce bloquée dans le board
           if(board[newY][newX] != VACANT){// Si la case au nouvelle coordonnée est différent VACANT
            return true;
           }
        }
    }
    return false;
}



// CONTROLER LA PIECE. Ajout d'un évenement 
document.addEventListener('keydown', controler);

function controler(event){
    //Correspond au numéro de touche au clavier
    if(event.keyCode == 37){
        piece.moveLeft();
        dropStart = Date.now(); // Pour éviter que la pièce tombe automatiquement pendant le repositionnement.
    }
    else if(event.keyCode == 38){
        piece.rotate();
        dropStart = Date.now();
    }
    else if(event.keyCode == 39){
        piece.moveRight();        
        dropStart = Date.now();
    }
    else if(event.keyCode == 40){
        piece.moveDown(); 
        dropStart = Date.now();      
    }
}



// Faire en sorte qu'une pièce descende toute les secondes. 
// Pour éviter que les pièces tombent trop vite, on doit contrôler le temps de chûte
let dropStart = Date.now();
let gameOver = false;
function drop(){
    let now = Date.now();
    let delta = now - dropStart;
    if(delta > 1000){ //Si delta est inférieur à une seconde
        piece.moveDown();
        dropStart = Date.now();
    } 
    if(!gameOver){
        // Notifie le navigateur que l'on souhaite exécuter une animation.
        //Appelé 60 fois par seconde
        requestAnimationFrame(drop);        
    }

}
drop();

//FONCTION POUR AFFICHER L'HEURE
//Création d'une fonction auto-invoquée(elle s'exécute elle-même)
(function () {
    function checkTime(i) {
        //Ternaire pour afficher le zéro quand l'heure est inférieur à 10
        //Est-ce que i est inférieur à 10: si oui, on concatène 0 et i entre eux. Sinon, on affiche i
        return (i < 10) ? "0" + i : i;
    }

    function startTime() {
        //Instancie un objet de Date
        var today = new Date(),
            h = checkTime(today.getHours()),
            m = checkTime(today.getMinutes()),
            s = checkTime(today.getSeconds());
            //Écrire du HTML dans la div time
        document.getElementById('time').innerHTML = h + ":" + m + ":" + s;
        //Toute les demi-seconde, on actualise
        t = setTimeout(function () {
            startTime()
        }, 500);
    }
    startTime();
})
();